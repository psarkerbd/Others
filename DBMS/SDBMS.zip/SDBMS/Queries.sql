1) 

select emp.person_name, street, city, company_name, salary from employee emp, works wrks where emp.person_name=wrks.person_name and city='Sylhet';

2)

select emp.person_name, emp.street from employee emp where city='Sylhet';

3)

select * from company;

4)

select * from company comp where city='Sylhet';

5)

select person_name, salary from works where salary = (select max(salary) from works); /* sub-query !!! My God !!! :( :( */

6)

select person_name, salary from works where salary ^= (select max(salary) from works);

7)

select avg(salary) from works;

8)

select company_name, avg(salary) from works group by company_name;

9)

select company_name, max(salary) from works group by company_name;

10)

select emp.person_name, wrks.company_name, emp.city from employee emp, works wrks where emp.person_name=wrks.person_name;

/*

11)

select emp.person_name, emp.city from employee emp, works wrks where emp.person_name = wrks.person_name and emp.city=emp.city and wrks.company_name=wrks.company_name;

*/

12)

select emp.person_name, man.manager_name from employee emp, manages man where emp.person_name = man.person_name and man.manager_name = 'Rahim';

13)

select man.person_name , man.manager_name from manages man where man.person_name = (select emp.person_name from employee emp where emp.person_name = 'Rahim');

14)

select emp.person_name, emp.street, emp.city, wrks.salary from employee emp, works wrks where emp.person_name = wrks.person_name and wrks.salary < 10000;

15)

select count(person_name) from works;

16)

select company_name, count(person_name) from works group by company_name;

17) /* not sure */

select count(salary) from works;

18)

select city , count(company_name) from company group by city;

19)

select man.manager_name from manages man where man.person_name = (select man.manager_name from manages man where man.person_name = (select emp.person_name from employee emp where emp.person_name = 'Rahim') );

20)

select company_name, city from company where 'Ltd' = (select substr(company_name, -3) from dual);

21)

select company_name, city from company where company_name like '%Tech%';
