
/* creating the employee table */
create table employee(
person_name varchar2(50) not null,
street varchar2(50),
city varchar2(50),
constraint person_name_pk primary key (person_name)
);

/* inserting the values in employee entity */
insert into
employee(person_name, street, city)
values ('Karim', 'Mirabazar', 'Sylhet');

insert into
employee(person_name, street, city)
values ('Rahim', 'Medical', 'Sylhet');

insert into
employee(person_name, street, city)
values ('Zafar', 'Banani', 'Dhaka');

insert into
employee(person_name, street, city)
values ('Mehedi', 'MoulaviBazar', 'Sylhet');

insert into
employee(person_name, street, city)
values ('Rafiq', 'Oxygen More', 'Chittagong');

insert into
employee(person_name, street, city)
values ('Kazi', 'SirajGonj', 'Rajshahi');

insert into
employee(person_name, street, city)
values ('Rahat', 'Sunamgonj', 'Sylhet');

select * from employee;

/*----------------------------------------------------------*/

/* creating the works entity */

create table works(
person_name varchar2(50) constraint person_name_fk references employee(person_name), /* single line foreign key */
company_name varchar2(50),
salary int
);

/* inserting data into works */
insert into
works(person_name, company_name, salary)
values ('Karim', 'NASA', 5000);

insert into
works(person_name, company_name, salary)
values ('Rahim', 'ITLTD' , 4000);

insert into
works(person_name, company_name, salary)
values ('Zafar', 'TALTD', 3000);

insert into
works(person_name, company_name, salary)
values ('Mehedi', 'AssProf', 2000);

insert into
works(person_name, company_name, salary)
values ('Rafiq', 'LaTech', 1000);

insert into
works(person_name, company_name, salary)
values ('Kazi', 'Partex', 5000);

insert into
works(person_name, company_name, salary)
values ('Rahat', 'NASA', 2500);

select * from works;

/*-----------------------------------------------------*/

/* creating company entity */
create table company(
company_name varchar2(50),
city varchar2(50),
constraint company_name_pk primary key(company_name)
);

/* inserting data into company entity */

insert into
company(company_name, city)
values ('NASA', 'Sylhet');

insert into
company(company_name, city)
values ('ITLTD' , 'Sylhet');

insert into
company(company_name, city)
values ('TALTD', 'Dhaka');

insert into
company(company_name, city)
values ('AssProf', 'Sylhet');

insert into
company(company_name, city)
values ('LaTech', 'Chittagong');

insert into
company(company_name, city)
values ('Partex', 'Rajshahi');

select * from company;

/*--------------------------------------------*/

/* creating the manages entity */

create table manages(
person_name varchar2(50) not null,
constraint fk_person_name
foreign key(person_name)
references employee(person_name),
manager_name varchar2(50)
);

/* inserting data into manages entity */

insert into
manages(person_name, manager_name)
values ('Karim', 'Rahim');

insert into
manages(person_name, manager_name)
values ('Rahim', 'Young');

insert into
manages(person_name, manager_name)
values ('Zafar', 'Djong');

insert into
manages(person_name, manager_name)
values ('Mehedi', 'Rahim');

insert into
manages(person_name, manager_name)
values ('Rafiq', 'Rahim');

select * from manages;

update manages set manager_name='Rahim' where person_name='Karim';

commit;