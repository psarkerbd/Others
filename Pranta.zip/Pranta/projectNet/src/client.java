
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mamun
 */
class cclient {
    
    void ccclient()
    {
        Socket so;
        DataInputStream dis;
        DataOutputStream dos;
        String str;
        Scanner in = new Scanner(System.in);
        
        try
        {
            so = new Socket("localhost", 4000);
            System.out.println("Connected ...");
            dos = new DataOutputStream(so.getOutputStream());
            while(true)
            {
                str = in.nextLine();
                if(str.equals(null)) break;
                dos.writeUTF(str);
                dos.flush();
                
            }
            
            //dos.close();
            //dis.close();
            
        }catch(Exception e)
        {
            System.out.println("Error ! ");
        }
    }
}

public class client
{
    public static void main(String [] args)
    {
        cclient ob = new cclient();
        ob.ccclient();
    }
}