
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mamun
 */
class sssserver {

    ServerSocket ss;
    Socket so;
    DataInputStream dis;
    DataOutputStream dos;
    
    sssserver()
    {
       try
       {
           ss = new ServerSocket(4000);
           so = new Socket();
           System.out.println("Waiting for connection....");
           so = ss.accept();
           System.out.println("Connected !");
           dis = new DataInputStream(so.getInputStream());
           sserial ob=new sserial();
           while(true)
           {
               String str;
               str = dis.readUTF();
               if(str.equals("on"))
               {
                   ob.dos.write('H');
                   //dos.writeUTF(str);
               }
               else if(str.equals("off"))
               {
                   ob.dos.write('L');
               }
               System.out.println(str);
               //dos.writeUTF(str);
               
               
           }
           
       }catch(Exception e)
       {
           System.out.println("Error !");
       }
    }
    
}

public class server
{
    public static void main(String [] args)
    {
        sssserver ob = new sssserver();
      
    }
}
