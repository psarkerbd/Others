
import java.io.DataOutputStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mamun
 */

//package room;

import gnu.io.NRSerialPort;
import java.io.BufferedReader;
import java.io.DataOutputStream;

class sserial
{
    NRSerialPort nrserial;
    DataOutputStream dos;
    //DataOutputStream dos;
    
   sserial()
   {
       try
       {
           nrserial = new NRSerialPort("COM4",9600);
           System.out.println("Waiting for Connection.... udutjb yidc ");
           nrserial.connect();
           System.out.println("Arduino connected !");
           dos=new DataOutputStream(nrserial.getOutputStream());
//           while(true)
//           {
//               dos.write('H');
//               System.out.println("H");
//               Thread.sleep(2000);
//               
//               
//               dos.write('L');
//               System.out.println("L");
//               Thread.sleep(2000);
//           }
       }catch(Exception e)
       {
           System.out.println("Error !" + e.getMessage());
       }
   }
}

public class serial {
    public static void main(String [] args)
    {
        sserial ob = new sserial();
        
    }
}
