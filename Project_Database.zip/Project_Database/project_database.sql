
CREATE TABLE gallery (
                photo_id INT AUTO_INCREMENT NOT NULL,
                photo_title VARCHAR(155) NOT NULL,
                photo_topic VARCHAR(55),
                photo VARCHAR(255) NOT NULL,
                date VARCHAR(255),
                PRIMARY KEY (photo_id)
);


CREATE TABLE admin (
                aid INT NOT NULL,
                user_name VARCHAR(55) NOT NULL,
                password VARCHAR(55) NOT NULL,
                PRIMARY KEY (aid)
);


CREATE TABLE User (
                nid INT NOT NULL,
                full_name VARCHAR(255) NOT NULL,
                user_name VARCHAR(35) NOT NULL,
                password VARCHAR(50) NOT NULL,
                father_name VARCHAR(80) NOT NULL,
                mother_name VARCHAR(80) NOT NULL,
                email VARCHAR(25) NOT NULL,
                phone VARCHAR(12) NOT NULL,
                dob VARCHAR(100) NOT NULL,
                gender VARCHAR(15) NOT NULL,
                blood_group VARCHAR(25) NOT NULL,
                village VARCHAR(20),
                post_office VARCHAR(30),
                thana VARCHAR(30),
                zilla VARCHAR(30),
                division VARCHAR(30),
                photo VARCHAR(255) NOT NULL,
                last_donate_date VARCHAR(25) NOT NULL,
                user_type BOOLEAN NOT NULL,
                status BOOLEAN NOT NULL,
                PRIMARY KEY (nid)
);


CREATE TABLE Rules (
                id INT NOT NULL,
                rules_and_regulation VARCHAR(255) NOT NULL,
                PRIMARY KEY (id)
);


CREATE TABLE Message (
                message_id INT AUTO_INCREMENT NOT NULL,
                nid VARCHAR(20) NOT NULL,
                text VARCHAR(255) NOT NULL,
                PRIMARY KEY (message_id)
);


CREATE TABLE Home (
                home_id INT NOT NULL,
                message VARCHAR(255),
                image VARCHAR(255),
                PRIMARY KEY (home_id)
);
