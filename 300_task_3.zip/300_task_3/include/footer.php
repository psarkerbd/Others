</div>

	    <div id="footer" style="color:white; text-size:20px;"> footer
		</div>
	  </div>

	</body>

</html> 