<!DOCTYPE html>
<html>

<head>
	<title>
		Task_3
	</title>
	<link href="css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
	
	<div id="header" style="text-align:center; font-size:50px; color:white"> this is a header </div>
	
