<?php include("include/header.php"); ?>
<?php include("include/database_connection.php"); ?>


<div id="body" style="font-size:20px"> 

<?php
		//Include of Header file
		if(isset($_REQUEST['add']))
		{
			$student_id=trim($_REQUEST['student_id']);
			$student_name=trim($_REQUEST['student_name']);
			$student_contact=trim($_REQUEST['student_contact']);
			$qry="select * from student_information where student_id='$student_id'";
			$res=mysql_query($qry);
			$row=mysql_fetch_row($res);
			if($row==0)
			{
				$qry="insert into student_information(student_id,student_name,student_contact) values('$student_id','$student_name','$student_contact')";
				mysql_query($qry);
				echo '<p style="color: green;"> Entry Successful... </p>';
			}
			else
				echo '<p style="color: red;"> Already added in the list !!! </p>';
		}
		if(isset($_REQUEST['del']))
		{
			$qry="delete from student_information where st_id_pk='$_REQUEST[st_id_pk]' ";
			mysql_query($qry);
			echo '<p style="color: green;"> Deleted Successful... </p>';
		}
		
		if(isset($_REQUEST['update_student']))
		{
			$student_id=trim($_REQUEST['student_id']);
			$student_name=trim($_REQUEST['student_name']);
			$student_contact=trim($_REQUEST['student_contact']);
			$qry="select * from student_information where st_id_pk='$student_id'";
			$res=mysql_query($qry);
			$row=mysql_fetch_row($res);
			
			if($row<=1)
			{
				$qry="update student_information 
				set
				student_id='$student_id',
				student_name='$student_name',
				student_contact='$student_contact'
				where st_id_pk='$_REQUEST[st_id_pk]' ";
				mysql_query($qry);
				echo '<p style="color: green;"> Update Successful... </p>';
			}
			
			else
				echo '<p style="color: red;"> Can\'t update already added in the list !!! </p>';
		}
	?>

		<?php
			if(isset($_REQUEST['edit']))
			{
				$qry="select * from student_information where st_id_pk='$_REQUEST[st_id_pk]' ";
				$res=mysql_query($qry);
				$arr=mysql_fetch_array($res);
		?>
				<form action="index.php" method="post">
				<table style="margin-top:50px;">
					<tr>
						<td>
							Student ID
						</td>
						<td>
							: <input type="text" name="student_id" value="<?php echo $arr['student_id']; ?>" required>
						</td>
					</tr>
					<tr>
						<td>
							Student Name
						</td>
						<td>
							: <input type="text" name="student_name" value="<?php echo $arr['student_name']; ?>" required>
						</td>
					</tr>
					<tr>
						<td>
							Student Contact
						</td>
						<td>
							: <input type="text" name="student_contact" value="<?php echo $arr['student_contact']; ?>" required>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="right">
							<input type="submit" name="update_student" value="Update Student">
							<input type="hidden" name="st_id_pk" value="<?php echo $arr['st_id_pk']; ?>">
						</td>
					</tr>
				<table>
				</form>
		<?php	
			}
			else
			{
		?>
				<form action="index.php" method="post">
				<table style="margin-top:50px;">
					<tr>
						<td>
							Student ID
						</td>
						<td>
							: <input type="text" name="student_id" required>
						</td>
					</tr>
					<tr>
						<td>
							  &nbsp &nbsp Student Name
						</td>
						<td>
							: <input type="text" name="student_name" required>
						</td>
					</tr>
					<tr>
						<td>
							  &nbsp &nbsp &nbsp Student Contact
						</td>
						<td>
							: <input type="text" name="student_contact" required>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="right">
							<input type="submit" name="add" value="Add Student">
						</td>
					</tr>
				<table>
				</form>
		<?php
			}
		?>
		
		<form action="index.php" method="post">
			<input type="text" name="se_val"  placeholder=" &nbsp &nbsp &nbsp type to search" style="margin-top:50px;margin-left:4px; margin-bottom:20px" required>
			<input type="submit" name="search" value="Search">
		</form>
		
		
		<table style="width:800px;border:2px solid black;margin-bottom:100px;text-align:center;background-color:black;">
		<tr>
			<td style="border:2px solid black; color:white">
				Student ID
			</td>
			<td style="border:2px solid black; color:white">
				Student Name
			</td>
			<td style="border:2px solid black; color:white">
				Student Contact
			</td>
			<td style="border:2px solid black; color:white">
				Action
			</td>
		</tr>
		<?php
			$fl=0;
			if(isset($_REQUEST['search']))
			{
				$qry="select * from student_information where student_id LIKE '%$_REQUEST[se_val]%' or student_name LIKE '%$_REQUEST[se_val]%' or student_contact LIKE '%$_REQUEST[se_val]%' order by st_id_pk desc ";
				$res=mysql_query($qry);
			}
			else
			{
				$qry="select * from student_information order by st_id_pk desc ";
				$res=mysql_query($qry);
			}
			
			while($arr=mysql_fetch_array($res))
			{
				$fl++;
		?>
			<tr>
				<td style="color:white">
					<?php echo $arr['student_id']; ?>
				</td>
				<td style="color:white">
					<?php echo $arr['student_name']; ?>
				</td>
				<td style="color:white">
					<?php echo $arr['student_contact']; ?>
				</td>
				<td>
					<a href="index.php?st_id_pk=<?php echo $arr['st_id_pk']; ?>&del=act"><button type="button" name="del" style="background-color:red; color:white">Delete</button></a>
					<a href="index.php?st_id_pk=<?php echo $arr['st_id_pk']; ?>&edit=act"><button type="button" name="edit" style="background-color:green; color:white">Edit</button></a>
				</td>
			</tr>
		<?php
			}
			if($fl==0)
			{
		?>
				<tr>
					<td colspan="4">
						<p style="color:red;text-align:center;"> No records found!!! </p>
					</td>
				</tr>
		<?php
			}
		?>
		<table>

</div>
<?php include("include/footer.php"); ?>

